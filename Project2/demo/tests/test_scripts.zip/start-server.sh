#!/bin/sh

./server 5000 > server1.txt 
